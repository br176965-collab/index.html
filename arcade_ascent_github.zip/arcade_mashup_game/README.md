# ARCADE ASCENT

A browser-playable prototype for the arcade mash-up game concept.

## Run
Open `index.html` in a browser, or upload the folder to a GitHub repository and enable **GitHub Pages**.

## Controls
- WASD / Arrow keys: move
- Space: fire
- E: use the charged cannon during the final boss
- R: restart after winning/losing

## Game structure
- 40 floors
- Donkey-Kong-inspired climbing arena
- Space-Invader-style enemies
- Tetris-style hazards
- Pac-style dots, ghosts and power-up logic
- Frogger/Snake-inspired enemies
- Q*bert-inspired vertical flavor
- Floor 30: WiFi-T-Rex boss
- Floor 40: final Arcade Construct boss
- Final escape sequence after the boss is defeated

This version uses original canvas-drawn placeholder visuals so the repository can run without external libraries.
